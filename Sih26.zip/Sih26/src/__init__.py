"""SIH26153: AI Based Network Attack Forecasting from Network Traffic Data
Core Package Initialization
"""

__version__ = "1.0.0"
