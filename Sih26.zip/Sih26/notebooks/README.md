# Exploratory Data Analysis & Research Notebooks

This directory is reserved for Jupyter exploratory prototypes and offline verification notebooks.
For CLI and dashboard operations, primary code resides in `src/` and entry points are `app.py` and `train.py`.
